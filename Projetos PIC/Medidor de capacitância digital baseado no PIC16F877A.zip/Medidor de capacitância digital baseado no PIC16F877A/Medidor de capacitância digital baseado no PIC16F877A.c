#define                 C2                1e-6
#define                 Ref_ADC           5.0
#define                 Max_ADC           1023.0
#define                 Init_Vlaue        0.0
#define                 Count_Max         256

/* Configurações de pinagem de LCD */
sbit LCD_RS at RB0_bit;
sbit LCD_EN at RB1_bit;
sbit LCD_D4 at RB2_bit;
sbit LCD_D5 at RB3_bit;
sbit LCD_D6 at RB4_bit;
sbit LCD_D7 at RB5_bit;

// Direção do pino
sbit LCD_RS_Direction at TRISB0_bit;
sbit LCD_EN_Direction at TRISB1_bit;
sbit LCD_D4_Direction at TRISB2_bit;
sbit LCD_D5_Direction at TRISB3_bit;
sbit LCD_D6_Direction at TRISB4_bit;
sbit LCD_D7_Direction at TRISB5_bit;


double                          Capa_uF=0.0;
double                          Max_Vin=0.0;
double                          Max_Vout=0.0;
double                          ADC_Volt=0.0;

unsigned int                    Data_ADC=0;
long                            Count_Perdiode=0;

long                            i=0;
char                            Capa_F_Char[16];
char                            Max_Vin_Char[16];
char                            Max_Vout_Char[16];

void main()
{
   // LCD de inicialização, ADC
   Lcd_Init();
   ADC_Init();
   Lcd_Cmd(_LCD_CLEAR);
   Lcd_Cmd(_LCD_CURSOR_OFF);

   Lcd_Out(1, 5, "Capacitância");
   Lcd_Out(2, 16, "uF");

   TRISA =  0xFF;
   TRISB =  0x00;

   PORTB=0x00;
   PORTB=0x00;

   ADCON1=0x00;

   while(1)
   {
       // Meça o valor máximo da tensão de entrada (Vin)
       Data_ADC= ADC_Read(0);
       ADC_Volt =(double)Data_ADC * Ref_ADC/Max_ADC;
       if( ADC_Volt>= Max_Vin)  Max_Vin= ADC_Volt;
       FloatToStr(Max_Vin, Max_Vin_Char);

       // Meça o valor máximo da tensão de saída (Vout)
       Data_ADC= ADC_Read(1);
       ADC_Volt =(double)Data_ADC * Ref_ADC/Max_ADC;
       if( ADC_Volt>= Max_Vout)  Max_Vout= ADC_Volt;
       FloatToStr(Max_Vout, Max_Vout_Char);

       // Calcule o valor do capacitor C1 em uF
       Capa_uF = 1e6*C2*((Max_Vin/Max_Vout) - 1.0);
       FloatToStr(Capa_uF, Capa_F_Char);
       
       // Atualize os valores máximos
       Count_Perdiode++;
       if( Count_Perdiode == Count_Max)
       {
           Max_Vout =Init_Vlaue;
           Max_Vin  = Init_Vlaue;
           Count_Perdiode=0;
       }

       // Exibição
       Lcd_Out(2,3,Capa_F_Char);
       Lcd_Out(2, 16, "uF");
       Lcd_Out(2,12,"   ");
       

   }

}
