// Configurações de bits de configuração PIC16F877A 
// Declarações de configuração da linha de origem 'C' 
#pragma config FOSC = EXTRC 
#pragma config WDTE = ON 
#pragma config PWRTE = OFF 
#pragma config BOREN = ON 
#pragma config LVP = ON 
#pragma config CPD = OFF 
#pragma config WRT = OFF 
#pragma config CP = OFF 

#define _XTAL_FREQ 8000000
#include <xc.h>

void main(void) 
{
TRISB=0x00;
while(1)
{
RB0 = 1 ;
__delay_ms(500);
RB0 = 0 ;
__delay_ms(500);

}
return;
}
