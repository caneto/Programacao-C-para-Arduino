from machine import Pin
from time import sleep
 
latchPin = Pin(3, Pin.OUT)
clockPin = Pin(2, Pin.OUT)
dataPin = Pin(4, Pin.OUT)
 
def update_shift_register(value):
    latchPin.value(0)
    for i in range(8):
        clockPin.value(0)
        dataPin.value((value >> (7 - i)) & 1)
        clockPin.value(1)
    latchPin.value(1)
 
def led_chase():
    for i in range(8):
        leds = 1 << i
        update_shift_register(leds)
        sleep(0.1)  # Adjust delay for speed
 
while True:
    led_chase()