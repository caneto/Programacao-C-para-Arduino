from machine import Pin, PWM
from time import sleep
 
latchPin = Pin(3, Pin.OUT)
clockPin = Pin(2, Pin.OUT)
dataPin = Pin(4, Pin.OUT)
 
def update_shift_register(value):
    latchPin.value(0)
    for i in range(8):
        clockPin.value(0)
        dataPin.value((value >> (7 - i)) & 1)
        clockPin.value(1)
    latchPin.value(1)
 
def fade_led(led_index, direction):
    for brightness in range(0, 256, 5):
        pwm_value = 255 - brightness if direction > 0 else brightness
        PWM(latchPin, freq=1000, duty_u16=pwm_value * 256)
        leds = (1 << led_index) if direction > 0 else 0
        update_shift_register(leds)
        sleep(0.005)  # Adjust delay for fading speed
 
while True:
    # Sweep from left to right
    for i in range(8):
        fade_led(i, 1)
        sleep(0.1)  # Adjust delay for speed
        fade_led(i, -1)
    # Sweep from right to left
    for i in range(7, -1, -1):
        fade_led(i, 1)
        sleep(0.1)  # Adjust delay for speed
        fade_led(i, -1)