from machine import Pin, I2C        #importing relevant modules & classes
from time import sleep
import bme280                       #importing BME280 library
from ssd1306 import SSD1306_I2C

i2c=I2C(0,sda=Pin(0), scl=Pin(1), freq=400000)    #initializing the I2C method 
oled = SSD1306_I2C(128, 64, i2c)

while True:
  oled.fill(0)
  bme = bme280.BME280(i2c=i2c)          #BME280 object created
  temperature = bme.values[0]           #reading the value of temperature
  pressure = bme.values[1]              #reading the value of pressure
  humidity = bme.values[2]              #reading the value of humidity

  print('Temperature: ', temperature)    #printing BME280 values
  print('Humidity: ', humidity)
  print('Pressure: ', pressure)
  
  oled.text("Temp "+temperature, 0, 0)
  oled.text("PA "+pressure, 0, 20)
  oled.text("Humidity "+humidity, 0,40)
  oled.show()                          #display 
  sleep(10)     #delay of 10s