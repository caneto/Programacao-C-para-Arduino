from machine import Pin
import utime
 
relay=Pin(18,Pin.OUT)        
 
while True:
  relay.value(1)            #Ajustar a ativação do relé
  utime.sleep(5)
  relay.value(0)            #Configurar o desligamento do relé
  utime.sleep(5)
