from machine import Pin, ADC
import utime
 
# Define pin numbers
step_pin = Pin(17, Pin.OUT)
dir_pin = Pin(16, Pin.OUT)
pot = ADC(26) # A0 is on GP26 on Pico
 
# Set motor direction
dir_pin.high()
 
def map_val(value, in_min, in_max, out_min, out_max):
    return (value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min
 
def loop():
    while True:
        # Read potentiometer value and map it to desired range
        custom_delay = pot.read_u16() # read 16 bit value
        custom_delay_mapped = map_val(custom_delay, 0, 65535, 300, 4000) # map 16 bit value to desired range
 
        # Pulse the stepper motor
        step_pin.high()
        utime.sleep_us(int(custom_delay_mapped))
        step_pin.low()
        utime.sleep_us(int(custom_delay_mapped))
 
# Start the loop
loop()