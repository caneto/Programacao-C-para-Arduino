from machine import Pin, I2C
import time
 
# Standard gravity (m/s²)
G = 9.80665
 
class  ADXL375:
    _REG_BW_RATE   = 0x2C
    _REG_POWER_CTL = 0x2D
    _REG_DATA      = 0x32   # DATAX0..DATAZ1
    _SCALE = 0.049 * G      # 0.049 g/LSB → m/s²
 
    def __init__(self, i2c, addr=0x53):
        self.i2c    = i2c
        self.addr   = addr
        # calibration offsets (m/s²)
        self.x_offset = 0.0
        self.y_offset = 0.0
        self.z_offset = 0.0
 
        # check device present
        if addr not in self.i2c.scan():
            raise OSError("ADXL375 not found at 0x%02X" % addr)
 
        # Standby → 100 Hz → Measure
        self._write(self._REG_POWER_CTL, 0x00)
        time.sleep_ms(10)
        self._write(self._REG_BW_RATE, 0x0A)   # 100 Hz
        self._write(self._REG_POWER_CTL, 0x08) # Measure on
        time.sleep_ms(10)
 
    def _write(self, reg, val):
        self.i2c.writeto_mem(self.addr, reg, bytes([val]))
 
    def _read(self, reg, n):
        return self.i2c.readfrom_mem(self.addr, reg, n)
 
    def _twos_comp(self, val, bits=16):
        if val & (1 << (bits - 1)):
            val -= (1 << bits)
        return val
 
    def read_raw(self):
        buf = self._read(self._REG_DATA, 6)
        x = buf[0] | (buf[1] << 8)
        y = buf[2] | (buf[3] << 8)
        z = buf[4] | (buf[5] << 8)
        return (
            self._twos_comp(x),
            self._twos_comp(y),
            self._twos_comp(z),
        )
 
    def read_mps2(self):
        x, y, z = self.read_raw()
        return (
            x * self._SCALE,
            y * self._SCALE,
            z * self._SCALE,
        )
 
    def calibrate(self, samples=100, delay_ms=20):
        """Auto-calibrate: assume sensor is flat & still."""
        sum_x = sum_y = sum_z = 0.0
        for _ in range(samples):
            x, y, z = self.read_mps2()
            sum_x += x
            sum_y += y
            sum_z += z
            time.sleep_ms(delay_ms)
        avg_x = sum_x / samples
        avg_y = sum_y / samples
        avg_z = sum_z / samples
 
        # X/Y→0, Z→+1 g
        self.x_offset = avg_x
        self.y_offset = avg_y
        self.z_offset = avg_z - G
 
        print("Calibration complete:")
        print("  x_offset = {:.4f} m/s²".format(self.x_offset))
        print("  y_offset = {:.4f} m/s²".format(self.y_offset))
        print("  z_offset = {:.4f} m/s²".format(self.z_offset))
 
# ——— Example usage ——————————————————————————————————————————
 
# I2C0: GP0=SDA, GP1=SCL
i2c = I2C(0, sda=Pin(0), scl=Pin(1), freq=400000)
 
try:
    accel = ADXL375(i2c)
except OSError as e:
    print(e)
    while True:
        time.sleep(1)
 
# Auto-calibrate (keep Pico + ADXL375 flat & still during this)
accel.calibrate()
 
print("\nReading calibrated acceleration (m/s²):\n")
while True:
    x, y, z = accel.read_mps2()
    # subtract offsets
    x -= accel.x_offset
    y -= accel.y_offset
    z -= accel.z_offset
 
    print("X:{:+6.2f}  Y:{:+6.2f}  Z:{:+6.2f}".format(x, y, z))
    time.sleep_ms(500)