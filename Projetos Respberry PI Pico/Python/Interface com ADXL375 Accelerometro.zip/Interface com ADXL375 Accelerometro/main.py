from machine import Pin, I2C
import time
 
class  ADXL375:
    _REG_BW_RATE   = 0x2C
    _REG_POWER_CTL = 0x2D
    _REG_DATA      = 0x32
    _SCALE = 0.049 * 9.80665  # g-scale → m/s²
 
    def __init__(self, i2c, addr=0x53):
        self.i2c  = i2c
        self.addr = addr
        if addr not in self.i2c.scan():
            raise OSError("ADXL375 not found at 0x%02X" % addr)
 
        # Standby → 100 Hz → Measure
        self._write(self._REG_POWER_CTL, 0x00)
        time.sleep_ms(10)
        self._write(self._REG_BW_RATE, 0x0A)
        self._write(self._REG_POWER_CTL, 0x08)
        time.sleep_ms(10)
 
    def _write(self, reg, val):
        self.i2c.writeto_mem(self.addr, reg, bytes([val]))
 
    def _read(self, reg, n):
        return self.i2c.readfrom_mem(self.addr, reg, n)
 
    def _twos_comp(self, val, bits=16):
        # convert unsigned to signed (two's complement)
        if val & (1 << (bits - 1)):
            val -= (1 << bits)
        return val
 
    def read_raw(self):
        buf = self._read(self._REG_DATA, 6)
        # little-endian, manual two’s-comp
        x = buf[0] | (buf[1] << 8)
        y = buf[2] | (buf[3] << 8)
        z = buf[4] | (buf[5] << 8)
        return (self._twos_comp(x),
                self._twos_comp(y),
                self._twos_comp(z))
 
    def read_mps2(self):
        x, y, z = self.read_raw()
        return (x * self._SCALE,
                y * self._SCALE,
                z * self._SCALE)
 
# ——— Example ——————————————————————————————
i2c = I2C(0, sda=Pin(0), scl=Pin(1), freq=400000)
 
try:
    accel = ADXL375(i2c)
except OSError as e:
    print(e)
    while True:
        time.sleep(1)
 
print("ADXL375 ready!")
 
while True:
    x, y, z = accel.read_mps2()
    print("X:{:+6.2f} Y:{:+6.2f} Z:{:+6.2f} m/s²".format(x, y, z))
    time.sleep_ms(500)