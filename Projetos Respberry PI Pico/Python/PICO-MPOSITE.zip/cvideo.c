//
// Title:	        Pico-mposite Video Output
// Author:	        CapSistema
// 

#include "memory.h"

#include "pico/stdlib.h"

#include "hardware/pio.h"
#include "hardware/dma.h"
#include "hardware/irq.h"

#include "cvideo.h"
#include "cvideo.pio.h"     // O código PIO montado

#define state_machine 0     // A máquina de estado PIO para usar
#define width 256           // Largura do bitmap em pixels
#define height 192          // Altura do bitmap em pixels
#define hsync_bp1 24        // Comprimento do pulso a 0,0v
#define hsync_bp2 48        // Comprimento do pulso a 0,3v
#define hdots 382           // Dados para hsync incluindo varanda dos fundos
#define piofreq 7.0f        // Frequência do relógio da máquina de estado
#define border_colour 11    // A cor da borda

#define pixel_start hsync_bp1 + hsync_bp2 + 18  // Onde os dados de pixel começam em pixel_buffer

uint dma_channel;           // Canal DMA para transferência de dados hsync para PIO
uint vline;                 // Linha de vídeo atual sendo processada
uint bline;                 // Linha no bitmap para buscar

#include "bitmap.h"         // O bitmap de demonstração

unsigned char vsync_ll[hdots+1];					// buffer para uma linha vsync com um pulso long/long 
unsigned char vsync_ls[hdots+1];					// buffer para uma linha vsync com um pulso long/short 
unsigned char vsync_ss[hdots+1];					// buffer para uma linha vsync com um pulso short/short
unsigned char border[hdots+1];						// Buffer para uma linha vsync para as bordas superior e inferior
unsigned char pixel_buffer[2][hdots+1];	        	// Buffer duplo para as linhas de varredura de dados de pixel

int main() {
    PIO pio = pio0;
    uint offset = pio_add_program(pio, &cvideo_program);	// Carregue o programa PIO

    dma_channel = dma_claim_unused_channel(true);			// Reivindique um canal DMA para a transferência hsync
    vline = 1;												// Inicialize o contador de linha de varredura de vídeo para 1
    bline = 0;												// E o índice no buffer de pixel de bitmap para 0

    write_vsync_l(&vsync_ll[0],        hdots>>1);			// Pré-construir uma linha longa / longa de vscan ....
    write_vsync_l(&vsync_ll[hdots>>1], hdots>>1);
    write_vsync_l(&vsync_ls[0],        hdots>>1);			// Uma linha longa / curta de vscan ...
    write_vsync_s(&vsync_ls[hdots>>1], hdots>>1);
    write_vsync_s(&vsync_ss[0],        hdots>>1);			// Uma linha curta / curta de vscan
    write_vsync_s(&vsync_ss[hdots>>1], hdots>>1);

    // Este bit pré-constrói a linha de varredura da borda
    memset(&border[0], border_colour, hdots);				// Preencha a borda com a cor da borda
    memset(&border[0], 1, hsync_bp1);				        // Adicione o pulso hsync
    memset(&border[hsync_bp1], 9, hsync_bp2);

	// Este bit pré-constrói as linhas de varredura do buffer de pixel adicionando o pulso hsync e as bordas horizontais esquerda e direita
	for(int i = 0; i < 2; i++) {							// Loop através dos buffers de pixel
        memset(&pixel_buffer[i][0], border_colour, hdots);	// Primeiro preencha o buffer com a cor da borda
        memset(&pixel_buffer[i][0], 1, hsync_bp1);			// Adicione o pulso hsync
        memset(&pixel_buffer[i][hsync_bp1], 9, hsync_bp2);
        memset(&pixel_buffer[i][pixel_start], 31, width);
    }

	// Inicialize o MOST
	pio_sm_set_enabled(pio, state_machine, false);                      // Desativar a máquina de estado PIO
    pio_sm_clear_fifos(pio, state_machine);	                            // Limpe os buffers PIO FIFO
    cvideo_initialise_pio(pio, state_machine, offset, 0, 5, piofreq);   // Inicialize o PIO (função em cvideo.pio)
    cvideo_configure_pio_dma(pio, state_machine, dma_channel, hdots+1); // Conecte o canal DMA à máquina de estado
    pio_sm_set_enabled(pio, state_machine, true);                       // Habilite a máquina de estado PIO

    // E começar tudo
    cvideo_dma_handler();       // Chame o manipulador de DMA como um único para inicializá-lo
    while (true) {              // E então apenas loop sem fazer nada
        tight_loop_contents();
    }
}

// Escreva um pulso vsync curto
// Parâmetros:
// - p: Ponteiro para o buffer para armazenar esses dados de sincronização
// - comprimento: o tamanho do buffer
void write_vsync_s(unsigned char *p, int length) {
    int pulse_width = length / 16;
    for(int i = 0; i < length; i++) {
        p[i] = i <= pulse_width ? 1 : 13;
    }
}

// Escreva um longo meio pulso vsync
// Parâmetros:
// - p: Ponteiro para o buffer para armazenar esses dados de sincronização
// - comprimento: o tamanho do buffer
void write_vsync_l(unsigned char *p, int length) {
    int pulse_width = length - (length / 16) - 1;
    for(int i = 0; i < length; i++) {
        p[i] = i >= pulse_width ? 13 : 1;
    }
}

// O manipulador de interrupção hblank
// Isso é acionado pela instrução irq set 0 no código PIO (cvideo.pio)
void cvideo_dma_handler(void) {

    // Mudar a condição no número da linha de varredura vertical (vline)
    // Cada instrução faz um dma_channel_set_read_addr para apontar o PIO para os próximos dados a serem produzidos
    switch(vline) {

        // Primeiro lide com as linhas de varredura de sincronização vertical
        // Também na linha de varredura 3, pré-carregue o primeiro pixel de linha de varredura do buffer
        case 1 ... 2: 
            dma_channel_set_read_addr(dma_channel, vsync_ll, true);
            break;
        case 3:
            dma_channel_set_read_addr(dma_channel, vsync_ls, true);
            memcpy(&pixel_buffer[bline & 1][pixel_start], &bitmap[bline], width);
            break;
        case 4 ... 5:
        case 310 ... 312:
            dma_channel_set_read_addr(dma_channel, vsync_ss, true);
            break;

        // Então as linhas de varredura da borda
        case 6 ... 68:
        case 260 ... 309:
            dma_channel_set_read_addr(dma_channel, border, true);
            break;

        // Agora aponte o dma para o primeiro buffer para os dados de pixel,
        // e pré-carregar os dados para a próxima linha de varredura
        default:
            // Configure o DMA para ler de um dos pixel_buffers
			dma_channel_set_read_addr(dma_channel, pixel_buffer[bline++ & 1], true);  
            // E memcpy a próxima linha de varredura para o outro buffer de pixel			
            memcpy(&pixel_buffer[bline & 1][pixel_start], &bitmap[bline], width);       
            break;
    }

    // Incrementar e embrulhar os contadores
    if(vline++ >= 312) {    // Se tivermos passado da linha de varredura inferior, então
        vline = 1;		    // Reinicializar o contador da linha de varredura
        bline = 0;		    // E o contador de índice de linha de buffer de pixel
    }

    // Finalmente, limpe a solicitação de interrupção pronta para a próxima interrupção de sincronização horizontal
    dma_hw->ints0 = 1u << dma_channel;		
}

// Configure o PIO DMA
// Parâmetros:
// - pio: O PIO ao qual anexar
// - sm: O número da máquina de estado
// - dma_channel: o canal DMA
// - buffer_size_words: Número de bytes para transferir
//
void cvideo_configure_pio_dma(PIO pio, uint sm, uint dma_channel, size_t buffer_size_words) {
    pio_sm_clear_fifos(pio, sm);
    dma_channel_config c = dma_channel_get_default_config(dma_channel);
    channel_config_set_transfer_data_size(&c, DMA_SIZE_8);
    channel_config_set_read_increment(&c, true);
    channel_config_set_dreq(&c, pio_get_dreq(pio, sm, true));
    dma_channel_configure(dma_channel, &c,
        &pio->txf[sm],              // Ponteiro de destino
        NULL,                       // Ponteiro de fonte
        buffer_size_words,          // Número de transferências
        true                        // Sinalizador de início (verdadeiro = iniciar imediatamente)
    );
    dma_channel_set_irq0_enabled(dma_channel, true);
    irq_set_exclusive_handler(DMA_IRQ_0, cvideo_dma_handler);
    irq_set_enabled(DMA_IRQ_0, true);
}