from machine import I2C, Pin
import EEPROM_CAT24C32 #Para biblioteca EEPROM de 32 bits ou 4KB. Altere isso de acordo com o nome da sua biblioteca.

sda=machine.Pin(0)
scl=machine.Pin(1)
i2c=machine.I2C(0,sda=sda, scl=scl, freq=400000)
print("Dispositivos I2C : ")
print(i2c.scan())

# i2caddr=80 #Defina o endereço I2C de sua EEPROM.
#
# eeprom = EEPROM_CAT24C32.CAT24C32(i2c,i2caddr)


# #Leia e imprima 32 bytes a partir do endereço de memória 0
# print(eeprom.read(0, 32))

# #Leia e imprima 32 bytes como uma string começando no endereço de memória 0
# print((eeprom.read(0, 32)).decode('utf-8'))

# # Leia e imprima toda a EEPROM. Esta demonstração foi construída para um EEPROM de 4 KB, portanto, 4096.
# print(eeprom.read(0,4096))

# # Gravar String no endereço de memória 0
# eeprom.write(0, 'Test string')

# # Limpe a EEPROM
# eeprom.wipe()

# # Grave várias páginas (bytes por página dependem da EEPROM. Esta demonstração é construída para uma EEPROM com 32 bytes por especificação de página. Verifique a ficha técnica para sua EEPROM)
# eeprom.write(0, b'abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ')

# # Leia várias páginas (Bytes por página dependem da EEPROM. Esta demonstração é construída para uma EEPROM com 32 bytes por especificação de página. Por favor, verifique a folha de dados para sua EEPROM)
# eeprom.read(0,64)

# # Gravações de várias páginas (preencha as páginas 0 e 1 com dados de teste)
# # A gravação é realizada em duas etapas, "0" x 32 na primeira página e, em seguida, "1" x 32 na próxima página
# # O endereço de memória estava no início de um limite de página, então cada gravação é uma gravação de página completa de 32 bytes
# # Esta demonstração é construída para um EEPROM com 32 bytes por especificação de página. Por favor, verifique a folha de dados para o seu EEPROM
# eeprom.write(0, b'0000000000000000000000000000000011111111111111111111111111111111')

# # Escritas parciais de página
# # Grave alguns bytes abrangendo duas páginas, não começando no limite da página
# # A gravação é realizada em duas etapas, "abc" na primeira página e "def" na próxima página
# # Esta demonstração é construída para um EEPROM com 32 bytes por especificação de página. Por favor, verifique a folha de dados para o seu EEPROM
# eeprom.write(29, b'abcdef')
# eeprom.read(0,64)
