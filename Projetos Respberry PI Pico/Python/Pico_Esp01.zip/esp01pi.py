from machine import UART
import machine
import _thread
import time

def ESP8266Webserver(HTMLFile):
    #Set variaveis
    recv=""
    recv_buf="" 
    uart = UART(1,115200) # uart em uart1 com baud de 115200
    # credenciais de wi-fi (se necessário)
    wifi_ssid = ("TP-LINK_9950")
    wifi_password = ("xxxxyyyy")
    
    #Função para lidar com a leitura do uart serial para um buffer
    def SerialRead(mode):
        SerialRecv = ""
        if mode == "0" :
            SerialRecv=str(uart.readline())
        else:
            SerialRecv=str(uart.read(mode))
        #substituir gera menos erros do que .decode("utf-8")
        SerialRecv=SerialRecv.replace("b'", "")
        SerialRecv=SerialRecv.replace("\\r", "")
        SerialRecv=SerialRecv.replace("\\n", "\n")
        SerialRecv=SerialRecv.replace("'", "")
        return SerialRecv

    print ("Configurando Webserver...")
    time.sleep(2)
# Conecte-se ao wi-fi, isso só precisa ser executado uma vez, o ESP manterá os detalhes do CWMODE e do wi-fi e reconectará após o ciclo de energia, deixando como comentário, a menos que tenha sido executado uma vez.
#     print ("  - Configuração AP Mode...")
#     uart.write('AT+CWMODE=1'+'\r\n')
#     time.sleep(2)
#     print ("  - Conectando à WiFi...")
#     uart.write('AT+CWJAP="'+wifi_ssid+'","'+wifi_password+'"'+'\r\n')
#     time.sleep(15)
    print ("  - Configurando Conexão Mode...")
    uart.write('AT+CIPMUX=1'+'\r\n')
    time.sleep(2)
    print ("  - Iniciando Webserver..")
    uart.write('AT+CIPSERVER=1,80'+'\r\n') #Start webserver on port 80
    time.sleep(2)
    print ("Webserver Pronto!")
    print("")

    while True:
        while True:
            #ler um byte de serial para o buffer
            recv=SerialRead(1)
            recv_buf=recv_buf+recv
                       
            if '+IPD' in recv_buf: # if the buffer contains IPD(a connection), then respond with HTML handshake
                HTMLFileObject = open (HTMLFile, "r")
                HTMLFileLines = HTMLFileObject.readlines()
                HTMLFileObject.close()
                uart.write('AT+CIPSEND=0,17'+'\r\n')
                time.sleep(0.1)
                uart.write('HTTP/1.1 200 OK'+'\r\n')
                time.sleep(0.1)
                uart.write('AT+CIPSEND=0,25'+'\r\n')
                time.sleep(0.1)
                uart.write('Content-Type: text/html'+'\r\n')
                time.sleep(0.1)
                uart.write('AT+CIPSEND=0,19'+'\r\n')
                time.sleep(0.1)            
                uart.write('Connection: close'+'\r\n')
                time.sleep(0.1)
                uart.write('AT+CIPSEND=0,2'+'\r\n')
                time.sleep(0.1)
                uart.write('\r\n')
                time.sleep(0.1)
                uart.write('AT+CIPSEND=0,17'+'\r\n')
                time.sleep(0.1)
                uart.write('<!DOCTYPE HTML>'+'\r\n')
                time.sleep(0.1)
                # Após o handshake, leia o arquivo html do pico e envie pela linha serial por linha com CIPSEND
                for line in HTMLFileLines:
                        cipsend=line.strip()
                        ciplength=str(len(cipsend)+2) # calcula o comprimento do byte de envio mais nova linha
                        uart.write('AT+CIPSEND=0,' + ciplength +'\r\n')
                        time.sleep(0.1)
                        uart.write(cipsend +'\r\n')
                        time.sleep(0.1) # Os comandos de suspensão evitam que o envio seja truncado e fora de ordem.
                uart.write('AT+CIPCLOSE=0'+'\r\n') # uma vez que o arquivo é enviado, feche a conexão
                time.sleep(4)
                recv_buf="" #redefinir buffer
                
            

    
#Coloque no código principal
website = ("/webpage.html") # este é o caminho para o arquivo html no sistema de arquivos pico
_thread.start_new_thread(ESP8266Webserver(website), ()) # inicia o servidor da web em um _thread
