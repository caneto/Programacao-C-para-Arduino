from machine import Pin, Timer
import time

led = Pin(25, Pin.OUT)
cricket = Pin(15, Pin.OUT)
timer = Timer()

def foo(timer):
    led.value(1)
    cricket.value(1)
    time.sleep(0.8)
    led.value(0)
    cricket.value(0)

# O freq = 0,00333 representa o intervalo de 5 minutos
timer.init(freq=0.00333, mode=Timer.PERIODIC, callback=foo)
