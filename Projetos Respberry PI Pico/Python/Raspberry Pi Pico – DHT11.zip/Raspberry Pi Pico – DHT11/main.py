from machine import Pin, I2C
from ssd1306 import SSD1306_I2C
import utime as time
from dht import DHT11, InvalidChecksum
 
WIDTH  = 128                                            # largura da tela oled
HEIGHT = 64                                             # altura da tela oled
 
i2c = I2C(0, scl=Pin(9), sda=Pin(8), freq=200000)       # Init I2C usando pinos GP8 e GP9 (pinos I2C0 padrão)
print("I2C Address      : "+hex(i2c.scan()[0]).upper()) # Exibir endereço do dispositivo
print("I2C Configuration: "+str(i2c))                   # Exibir configuração I2C

oled = SSD1306_I2C(WIDTH, HEIGHT, i2c)                  # Init, você está em exibição
 
while True:
    time.sleep(1)
    pin = Pin(28, Pin.OUT, Pin.PULL_DOWN)
    sensor = DHT11(pin)
    t  = (sensor.temperature)
    h = (sensor.humidity)
    print("Temperature: {}".format(sensor.temperature))
    print("Humidity: {}".format(sensor.humidity))
    # Limpe o display do oled caso ele tenha algum lixo nele.
    oled.fill(0) 

 # Adicione algum texto
    oled.text("Temp: ",10,10)
    oled.text(str(sensor.temperature),50,10)
    oled.text("*C",90,10)
    
    oled.text("Humi: ",10,30)
    oled.text(str(sensor.humidity),50,30)
    oled.text("%",90,30)
    
    time.sleep(1)
    oled.show()
