import machine, onewire, ds18x20
from machine import Pin, I2C
from time import sleep
from ssd1306 import SSD1306_I2C

i2c=I2C(0,sda=Pin(0), scl=Pin(1), freq=400000)
oled = SSD1306_I2C(128, 64, i2c)

ds_pin = machine.Pin(2)
 
ds_sensor = ds18x20.DS18X20(onewire.OneWire(ds_pin))
 
roms = ds_sensor.scan()
 
print('Found DS devices')
print('Temperature (°C)')
 
while True:
 
  ds_sensor.convert_temp()
 
  sleep(1)
 
  for rom in roms:
 
    print(ds_sensor.read_temp(rom))
    oled.fill(0)
    oled.text("Temperature (C)", 0, 16)
    oled.text(str(ds_sensor.read_temp(rom)), 0, 35)
    oled.show()
 
  sleep(3)