from machine import Pin, I2C
from hcsr04 import HCSR04
from time import sleep
from ssd1306 import SSD1306_I2C

sensor = HCSR04(trigger_pin=2, echo_pin=3, echo_timeout_us=10000)

i2c=I2C(0,sda=Pin(0), scl=Pin(1), freq=400000)    #initializing the I2C method 
oled = SSD1306_I2C(128, 64, i2c)

while True:
  oled.fill(0)
  distance = str(sensor.distance_cm())

  oled.text("Distance", 0,15)
  oled.text(distance +" cm", 0,35)
  oled.show()
  sleep(1)