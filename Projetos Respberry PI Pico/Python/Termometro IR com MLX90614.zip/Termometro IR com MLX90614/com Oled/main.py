from machine import Pin, SoftI2C, I2C
import time
from ssd1306 import SSD1306_I2C
 
# MLX90614 I2C address and register addresses
MLX90614_I2C_ADDR = 0x5A
MLX90614_TA = 0x06  # Ambient temperature register
MLX90614_TOBJ1 = 0x07  # Object temperature register
 
# Initialize I2C for MLX90614 sensor
i2c_sensor = SoftI2C(sda=Pin(0), scl=Pin(1), freq=100000)
 
# OLED Display Setup
WIDTH, HEIGHT = 128, 64
i2c_display = I2C(1, scl=Pin(19), sda=Pin(18), freq=200000)
oled = SSD1306_I2C(WIDTH, HEIGHT, i2c_display)
 
def read_temp(register):
    data = i2c_sensor.readfrom_mem(MLX90614_I2C_ADDR, register, 3)
    temp = (data[1] << 8) | data[0]
    temp = (temp * 0.02) - 273.15  # Convert from Kelvin to Celsius
    return temp
 
def center_text(text, line, font_width=8):
    # Calculate starting x position based on text length
    x = max(0, (WIDTH - len(text) * font_width) // 2)
    oled.text(text, x, line)
 
try:
    print("* MLX90614 Temperature Readings *")
 
    while True:
        object_temp = read_temp(MLX90614_TOBJ1)
        ambient_temp = read_temp(MLX90614_TA)
        
        # Clear the display before adding new text
        oled.fill(0)
        
        # Display temperatures
        obj_temp_str = "{:.2f}C".format(object_temp)
        amb_temp_str = "{:.2f}C".format(ambient_temp)
        
        center_text("Object Temp:", 10)
        center_text(obj_temp_str, 20)  # Adjust line spacing as needed
        center_text("Ambient Temp:", 40)
        center_text(amb_temp_str, 50)
        
        # Update the display with new content
        oled.show()
        
        # Print the readings to the console as well
        print("Object Temperature: {:>5.2f}°C".format(object_temp))
        print("Ambient Temperature: {:>5.2f}°C".format(ambient_temp))
        
        time.sleep(1)
 
except KeyboardInterrupt:
    print('\nScript stopped by user')
 
finally:
    print('Goodbye!')