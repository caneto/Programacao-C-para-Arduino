from machine import Pin
import time

led_pins = [16,17,18] # pinos onde o LED RGB está conectado
leds = [Pin(led_pins[0],Pin.OUT),Pin(led_pins[1],Pin.OUT),
        Pin(led_pins[2],Pin.OUT)] # matriz de controle de pinos
delay_t = 0.1 # seconds to delay between toggles
while True: # Loop infinitamente
    for led in leds: # loop através de cada led
        led.high() # Led ligado
        time.sleep(delay_t) # espera
        led.low() # Led desligado
        time.sleep(delay_t) # espera
