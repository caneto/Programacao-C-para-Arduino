import time
from machine import Pin,PWM

pwm_pins = [16,17,18] # definir pinos PWM
pwms = [PWM(Pin(pwm_pins[0])),PWM(Pin(pwm_pins[1])),
                PWM(Pin(pwm_pins[2]))] # matriz pwm
[pwm.freq(1000) for pwm in pwms] # definir freqs pwm

step_val = 64 # valor da etapa para respiração de 16 bits
range_0 = [ii for ii in range(0,2**16,step_val)] # iluminando
range_1 = [ii for ii in range(2**16,-step_val,-step_val)] # escurecimento

while True: # loop indefinitely
    # looping através da respiração vermelha, azul e verde
    for pwm in pwms: 
           for ii in range_0+range_1:
               pwm.duty_u16(ii) # definir o ciclo de trabalho de 16 bits
               time.sleep(0.001) # dormir 1ms entre mudança pwm
    # respiração de pixel branco (todos os três LEDs)
    for ii in range_0+range_1:
        for pwm in pwms:
            pwm.duty_u16(ii) # definir o ciclo de trabalho
        time.sleep(0.001) # espere 1ms
