from machine import I2C, Pin
from time import sleep
from machine_i2c_lcd import I2cLcd
i2c = I2C(0, sda=Pin(0), scl=Pin(1), freq=400000)

I2C_ADDR = i2c.scan()[0]
lcd = I2cLcd(i2c, I2C_ADDR, 2, 16)
while True:
    print(I2C_ADDR)
    lcd.blink_cursor_on()
    lcd.putstr(" Endereço I2C :"+str(I2C_ADDR)+"\n")
    lcd.putstr(“CapSistema")
    sleep(2)
    lcd.clear()
    lcd.putstr(" Endereço I2C :"+str(hex(I2C_ADDR))+"\n")
    lcd.putstr(“CapSistema")
    sleep(2)
    lcd.blink_cursor_off()
    lcd.clear()
    lcd.putstr(" Teste de luz de fundo ")
    for i in range(10):
        lcd.backlight_on()
        sleep(0.2)
        lcd.backlight_off()
        sleep(0.2)
    lcd.backlight_on()
    lcd.hide_cursor()
    for i in range(20):
        lcd.putstr(str(i))
        sleep(0.4)
        lcd.clear()
